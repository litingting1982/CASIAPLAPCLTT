The code CH4WORLD.f90 written in Fortran 90 is for marsh, swamp, peatland, interwetland and no specific wetland.The code CH4coastal.f90 written in Fortran 90 is for coastal wetland.
This code is used to simulate daily CH4 fluxes from each 0.5*0.5 degree grid. 
We have 6 kinds of wetland. Number 4 is for marsh (e.g., parameter4.txt, and the filefolders Tairday4, npp4, Tsoilday4, wtday4). Similarly number 5, 6, 8,9 and 10 are for swamp, coastal wetland, peatland, interwetland and no-specific wetland type. Users can download the input files and parameter files into your computer and change the pathway of the files in the code. 
Please note that this code run for the year 1950 to 2010. Users can change the year and get the output of the CH4 fluxes from the specific year.
The output of each file represents the day, daily aboveground biomass, maximum aboveground biomass, litter from last year, daily root litter, daily CH4 production rate, daily plant emission, daily bubble emission, daily diffusion, daily total CH4 emission, temerature index. 
Useres can choose the specific output according to their requirement.
